package com.mycompany.project;
import java.util.*;
import java.io.*;

class appointment{
    int id;
    String date;
    ArrayList<appointment> pedningappointments=new ArrayList<>();
    void saveappointment(int id,String date,int patient_id,String patient_name){
        this.id=id;
        this.date=date;
        pedningappointments.add(this); 
        try {
        int c=0;
        File counter=new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\counter.txt");
        if(counter.exists()){
            Scanner input=new Scanner(counter);
            while(input.hasNextInt()){
                c=input.nextInt();
            }
        }
        c++;
        PrintWriter count=new PrintWriter(counter);   
        count.print(c);
        count.close();
        String appid=c + ".txt";
        File schedule = new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\appiontments\\"+appid); 
        FileWriter app=new FileWriter(schedule, true);     
        app.append("Patient info is : " + "\n" +patient_id+"  "+patient_name +"\nIs appointment Scheduling From the doctor's Id "+this.id+" in: " +this.date+"\n"+"\n");
        app.close();
        System.out.println("Your appointment was saved");
        }catch(Exception e){
            System.out.println(e);
        } 
    }
}

abstract class Admin {

    public abstract void Managing_Appointments();
    public abstract void Prescribe_medications();
    public abstract void view_reports();

    void edit_doc() {
        list_doc();
        System.out.print("Which department does the doctor belong to? \n1. Cardiology Clinic.\n2. Dental Clinic.\n3. Dermatology Clinic.\n4. Emergency Clinic.\n");
        int d_s = Project.in.nextInt();
        if (Project.Doctors.containsKey(d_s)) {
            System.out.print("id :");
            int id=Project.in.nextInt();
            ArrayList<Doctor> doctors = Project.Doctors.get(d_s);
            
            for (Doctor doctor : doctors) {
                if(doctor.doctor_id ==id){
                System.out.println("What do you want to edit? \n1.Name \n2.Specialization \n3.Exit");
                
                int choice = Project.in.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter  the new name of the doctor: ");
                        String newName = Project.in.next();
                        doctor.doctor_name = newName;
                        System.out.println("Doctor's name was updated to " + newName);
                        break;
                        
                    
                    case 2:
                        System.out.print("Enter the new specialization for the doctor : ");
                        String newSpecialization = Project.in.next();
                        doctor.specialization = newSpecialization;
                        System.out.println("Doctor's specialization was updated to " + newSpecialization);
                        break;
                    
                    case 3:
                        System.out.println("Exiting doctor edit.");
                        break;
                    
                    default:
                        System.out.println("Invalid choice, please try again.");
                }
            try(RandomAccessFile raf = new RandomAccessFile("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\doctors.txt", "rw")){
                 raf.setLength(0);
                 raf.writeBytes(String.valueOf(Project.doc_c) + "\n");
            for (int department = 1; department <= Project.department.size(); department++) {
                if (Project.Doctors.containsKey(department)) {
                    for (Doctor z : Project.Doctors.get(department)) {
                        raf.writeBytes(z.doctor_id+ " " + z.doctor_name+ " " + z.specialization + "\n");
                    }
                }
            }
            }catch(Exception e){
            System.out.println(e);
        }
            break;
        }System.out.println("Doctor not found.");
            }
        }else {
            System.out.println("Department not found.");
        }
    }

void edit_patient() {
    System.out.println("What is the ID of the patient you want to edit?");
    int id = Project.in.nextInt();

    if (Project.patient.containsKey(id)) {
        ArrayList<Patient> patients = Project.patient.get(id);

        for (Patient patient : patients) {
            System.out.println("Editing Patient: " + patient);
            System.out.println("What do you want to edit? \n1.Name \n2.Patient ID \n3.Exit");
            int choice = Project.in.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter the new name of the patient: ");
                    String newName = Project.in.next();
                    patient.patient_name = newName;
                    System.out.println("Patient's name updated to " + newName);
                    break;

                case 2:
                    System.out.print("Enter the new ID for the patient: ");
                    int newId = Project.in.nextInt();
                    if (!Project.patient.containsKey(newId)) {
                        Project.patient.remove(id);
                        patient.patient_id = newId;  
                        Project.patient.put(newId, new ArrayList<>(List.of(patient)));  
                        System.out.println("Patient's ID was updated to " + newId);
                    } else {
                        System.out.println("New ID already exists. Please choose a different ID.");
                    }
                    break;

                case 3:
                    System.out.println("Exiting patient edit.");
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }

        
        try (RandomAccessFile raf = new RandomAccessFile("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\patients.txt", "rw")) {
            raf.setLength(0);  // Clear the file

            for (Map.Entry<Integer, ArrayList<Patient>> entry : Project.patient.entrySet()) {
                for (Patient patient : entry.getValue()) {
                    raf.writeBytes(patient.patient_id + " " + patient.patient_name + "\n");
                }
            }
        } catch (Exception e) {
            System.out.println("Error updating the file: " + e.getMessage());
        }
    } else {
        System.out.println("Patient with ID " + id + " not found.");
    }
}
    void edit_depatrtment() {
    System.out.println("What is the name of the department you want to edit?");
    String departmentName = Project.in.next();

    if (Project.department.contains(departmentName)) {
        System.out.println("Department found: " + departmentName);
        System.out.println("What do you want to do? \n1.Change Department Name \n2.Exit");
        int choice = Project.in.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter new department name: ");
                String newDepartmentName = Project.in.next();
                int index = Project.department.indexOf(departmentName);
                Project.department.set(index, newDepartmentName);
                System.out.println("Department name updated to " + newDepartmentName);
                break;
           
            case 2:
                System.out.println("Exiting department edit.");
                break;

            default:
                System.out.println("Invalid choice, please try again.");
        }

        try (RandomAccessFile raf = new RandomAccessFile("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\departments.txt", "rw")) {
            raf.setLength(0);

            for (String dept : Project.department) {
                raf.writeBytes(dept + "\n");
            }
        } catch (Exception e) {
            System.out.println("Error updating the file: " + e.getMessage());
        }
    } else {
        System.out.println("Department " + departmentName + " not found.");
    }
}

    void add_doc() {
        System.out.print("What is the Doctor's name: ");
        String d_n = Project.in.next();
        System.out.print("What is the Doctor's Id: ");
        int d_id = Project.in.nextInt();
        System.out.print("What is the departement: \n1. Cardiology Clinic.\n2. Dental Clinic.\n3. Dermatology Clinic.\n4. Emergency Clinic.\n");
        int d_s = Project.in.nextInt();
        
        String dKey = switch(d_s){
                case 1->"Cardiology" ;
                case 2-> "Dental";
                case 3-> "Dermatology";
                case 4-> "Emergency";
                default -> throw new IllegalArgumentException("Unknown specialization: " + d_s);
        };
        Doctor doctor = new Doctor(d_id, d_n, dKey);
        Project.Doctors.get(d_s).add(doctor);
        Project.doc_c++;
        try{      
            File counter=new File("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\doctors.txt");
            RandomAccessFile raf = new RandomAccessFile(counter, "rw");
            raf.seek(0);
            raf.writeBytes(String.valueOf(Project.doc_c) + "\n");

            raf.seek(raf.length());
            raf.writeBytes(d_id + " " + d_n + " " + dKey + "\n");
            
            raf.close();
        }catch(Exception e){
            System.out.println(e);
        }
         System.out.println("Doctor added successfully.");
    }

    void add_patient() {
        System.out.print("What is the patient's name: ");
        String p_n = Project.in.next();
        System.out.print("What is the patient's Id: ");
        int p_id = Project.in.nextInt();
        Patient patient = new Patient(p_id, p_n);
        
        if (Project.patient.containsKey(p_id)) {
                System.out.println("id is already exists");
            }else{
            Project.patient.put(p_id, new ArrayList<>());
            Project.patient.get(p_id).add(patient);
        try{      
            File counter=new File("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\patients.txt");
            RandomAccessFile raf = new RandomAccessFile(counter, "rw");

            raf.seek(raf.length());
            raf.writeBytes(p_id + " " + p_n + " " + "\n");
            
            raf.close();
        }catch(Exception e){
            System.out.println(e);
        }
         System.out.println("Patient added successfully.");
    }
    }

    void add_depatrtment() {
        System.out.print("What is the department's name: ");
        String d_n = Project.in.next();
        Project.department.add(d_n);
        try{      
            File counter=new File("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\departments.txt");
            RandomAccessFile raf = new RandomAccessFile(counter, "rw");

            raf.seek(raf.length());
            raf.writeBytes(d_n + "\n");
            
            raf.close();
        }catch(Exception e){
            System.out.println(e);
        }
         System.out.println("Department added successfully.");
    }

    void delete_doc() {
        int d_s = 0;
    while (true) {
        System.out.print("Which department does the doctor belong to? \n1. Cardiology Clinic.\n2. Dental Clinic.\n3. Dermatology Clinic.\n4. Emergency Clinic.\n");
        d_s = Project.in.nextInt();
        
        if (d_s >= 1 && d_s <= 4) {
            break;
        } else {
            System.out.println("Invalid input. Please enter a number between 1 and 4.");
        }
    }

    System.out.print("Enter the Doctor's ID to delete: ");
    int d_id = Project.in.nextInt();
    boolean doctorFound = false;
    if (Project.Doctors.containsKey(d_s)) {
        List<Doctor> doctorsList = Project.Doctors.get(d_s);
        for (Doctor doctor : doctorsList) {
            if (doctor.doctor_id== d_id) {
                doctorsList.remove(doctor);
                doctorFound = true;
                break;
            }
        }
    }

    if (doctorFound) {
        try (RandomAccessFile raf = new RandomAccessFile("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\doctors.txt", "rw")) {
            Project.doc_c--;
            raf.setLength(0);
            raf.writeBytes(String.valueOf(Project.doc_c) + "\n");
            for (int department = 1; department <= Project.department.size(); department++) {
                if (Project.Doctors.containsKey(department)) {
                    for (Doctor doctor : Project.Doctors.get(department)) {
                        raf.writeBytes(doctor.doctor_id+ " " + doctor.doctor_name+ " " + doctor.specialization + "\n");
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Error updating the file: " + e.getMessage());
        }

        System.out.println("Doctor with ID " + d_id + " has been successfully deleted.");
    } else {
        System.out.println("Doctor with ID " + d_id + " not found in the selected department.");
    }
    }

 void delete_patient() {
    System.out.print("Enter the patient's ID to delete: ");
    int p_id = Project.in.nextInt();

    if (Project.patient.containsKey(p_id)) {
        Project.patient.remove(p_id);

        try (RandomAccessFile raf = new RandomAccessFile("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\patients.txt", "rw")) {
            raf.setLength(0);

            for (Map.Entry<Integer, ArrayList<Patient>> entry : Project.patient.entrySet()) {
                for (Patient patient : entry.getValue()) {
                    raf.writeBytes(patient.patient_id + " " + patient.patient_name + "\n");
                }
            }
        } catch (Exception e) {
            System.out.println("Error updating the file: " + e.getMessage());
        }

        System.out.println("Patient with ID " + p_id + " has been successfully deleted.");
    } else {
        System.out.println("Patient with ID " + p_id + " not found.");
    }
}
void delete_department() {
    System.out.print("Enter the department's name to delete: ");
    String d_n = Project.in.next();

    if (Project.department.contains(d_n)) {
        Project.department.remove(d_n);

        try (RandomAccessFile raf = new RandomAccessFile("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\departments.txt", "rw")) {
            raf.setLength(0);

            for (String department : Project.department) {
                raf.writeBytes(department + "\n");
            }
        } catch (Exception e) {
            System.out.println("Error updating the file: " + e.getMessage());
        }

        System.out.println("Department " + d_n + " has been successfully deleted.");
    } else {
        System.out.println("Department " + d_n + " not found.");
    }
}

    void list_doc() {System.out.println(Project.Doctors);}

    void list_patient() { System.out.println(Project.patient);}

    void list_depatrtment() {System.out.println(Project.department);}
    
    void view_report(){
    try{
            int c=0;
            File counter=new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\counter.txt");
            if(counter.exists()){
            Scanner input=new Scanner(counter);
            while(input.hasNextInt()){
                c=input.nextInt();
            }
        }
                String appid=c + ".txt";
                File report = new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\Report patient "+appid); 
                Scanner input=new Scanner(report);
                while(input.hasNext()){
                System.out.println(input.nextLine());
            }
                input.close();
            }catch(Exception e){
            System.out.println(e);
        }
    }
}



class Doctor extends Admin{
    int doctor_id;
    String doctor_name;
    String specialization;
    Scanner in=new Scanner(System.in);
    public Doctor(int doctor_id, String doctor_name, String specialization) {
        this.doctor_id = doctor_id;
        this.doctor_name = doctor_name;
        this.specialization = specialization;
    }
    
    public Doctor() {}
    
    @Override
    public String toString() {
        return "Doctor's ID=" + doctor_id + ", Doctor's Name :" + doctor_name + "\n";
    } 
    
    public void Managing_Appointments(){
        int choice=0;
        while (choice !=4){
        try {
        int c=0;
        File counter=new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\counter.txt");
        if(counter.exists()){
            Scanner input=new Scanner(counter);
            while(input.hasNextInt()){
                c=input.nextInt();
            }
        }
         String appid=c + ".txt";
         File schedule = new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\appiontments\\"+appid); 
         long x=schedule.length();
         if(schedule.exists()){
             if(x==0){System.out.println("There is no schedule");choice=4;}
             else
             {
                Scanner input=new Scanner(schedule);
                while(input.hasNext()){
                System.out.println(input.nextLine());
             }
         System.out.println("What is your Choice : \n 1.Accept \n 2.Cancel \n 3.Reschedule \n 4.Exit");
          int Choice= in.nextInt();
          if (choice == 4) 
          {
            System.out.println("Exiting Appointment Scheduling.");
            break;
          }
          FileWriter app=new FileWriter(schedule, true);   
        switch(Choice){
            case 1:
                app.append("Your requist accepted");
                app.close();
                break;
            case 2:
                app.append("Your requist cancelled");
                app.close();
                break;
            case 3:
                app.append("Please requiest another date");
                app.close();
                break;
                }
            }
        }
        }catch(Exception e){
            System.out.println(e);
        } 
    }
}
    
    public void Prescribe_medications (){
        try{
            int c=0;
            File counter=new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\counter.txt");
            if(counter.exists()){
            Scanner input=new Scanner(counter);
            while(input.hasNextInt()){
            c=input.nextInt();
            }
        }
            String appid=c + ".txt";
            String streport;
            File report = new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\Report patient "+appid); 
            FileWriter app=new FileWriter(report, true);  
            System.out.print("What is the report About :");
            String st=Project.in.next();
            app.append(st);
            app.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    public void view_reports(){
         try{
            int c=0;
            File counter=new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\counter.txt");
            if(counter.exists()){
            Scanner input=new Scanner(counter);
            while(input.hasNextInt()){
                c=input.nextInt();
            }
        }
                String appid=c + ".txt";
                File report = new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\Report patient "+appid); 
                Scanner input=new Scanner(report);
                while(input.hasNext()){
                System.out.println(input.nextLine());
            }
                input.close();
            }catch(Exception e){
            System.out.println(e);
        }
    }
}

class Patient extends appointment
{
    int patient_id;
    String patient_name;

    @Override
    public String toString() {
        return "Patient{" + "patient_id=" + patient_id + ", patient_name=" + patient_name + '}';
    }
    
    public Patient(int patient_id, String patient_name) {
        this.patient_id = patient_id;
        this.patient_name = patient_name;
        
    }
    
    void requestappointment(){
        int choice = 0;
        while (choice != 5) 
        {
            System.out.println("Choose Department (1, 2, 3, 4, 5 to Exit): ");
            System.out.println("\t1. Cardiology Clinic.");
            System.out.println("\t2. Dental Clinic.");
            System.out.println("\t3. Dermatology Clinic.");
            System.out.println("\t4. Emergency Clinic.");
            System.out.println("\t5. Exit");
            choice = Project.in.nextInt();
            if (choice < 1 || choice > 5) {
                System.out.println("Invalid choice. Please try again.");
                continue;
            }
            String departmentName = "";
            switch (choice) {
                case 1:
                    departmentName = "Cardiology";
                    break;
                case 2:
                    departmentName = "Dental";
                    break;
                case 3:
                    departmentName = "Dermatology";
                    break;
                case 4:
                    departmentName = "Emergency";
                    break;
                case 5:
                    choice =5;
                    break;
            }

           if(choice ==5){
           System.out.println("Exiting");
           }
           
           else if (Project.Doctors.containsKey(choice)) {
                int counter=0;
                System.out.println("Available doctors in " + departmentName + " department:");
                for (Doctor doctor : Project.Doctors.get(choice)) {
                    System.out.println(doctor);
                }
                System.out.println("choose Doctor's Id: ");
                int doctor_num=Project.in.nextInt();
                
                System.out.println("Enter the date:");
                String date=Project.in.next();
            saveappointment(doctor_num,date,patient_id,patient_name);
            }else 
                System.out.println("No doctors available in this department.");
        }
        
    }
    
    void Accessing_Medical_Record(){
    try{
        String streport="";
        File report = new File("C:\\Users\\hp\\Desktop\\OOP\\Project\\src\\main\\java\\com\\mycompany\\project\\Report.txt"); 
          if(report.exists()){
            Scanner input=new Scanner(report);
            while(input.hasNext()){
                streport+=input.next();
            }
        }
          System.out.println(streport);
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    void Accessing_Billing(){
        int choice =0;
        if(choice!=4){
        int value =0;
        while(choice!=5){
        System.out.println("What did you take? \n 1.medicine \n 2.Requesting an appionment \n 3.Having a report \n 4.Your total \n 5.End ");
        choice=Project.in.nextInt();
        switch(choice){
            case 1:
                value += 150;
                break;
            case 2:
                value += 200;
                break;
            case 3:
                value += 50;
                break;
            case 4:
                System.out.println("Your total amount is : "+ value);
                choice =5;
                break;
            case 5:
                choice =5;
                break;
            default:
                System.out.println("Invalid choice");
        }     
        }
        }
    }
}
class man{
    
    public void Adminmain(){
        Admin admin=new Doctor();
        int choice=0;
        while(choice!=6){
        System.out.println("What do you want to do? \n 1.Staff \n 2.Patient \n 3.Department \n 4.View staff Reports \n 5.View patient reports \n 6.Exit");
        choice =Project.in.nextInt();
        switch(choice){
            case 1:
                    System.out.println("What do you want to do? \n 1.edit \n 2.add \n 3.delete \n 4.list");
                    int choice_2 =Project.in.nextInt();
                    switch(choice_2){
                        case 1: admin.edit_doc();
                            break; 
                        case 2: admin.add_doc();
                            break; 
                        case 3: admin.delete_doc();
                            break; 
                        case 4: admin.list_doc();
                            break; 
                        default:System.out.println("Invalide choice");
                    }
                break;
                
            case 2:
                System.out.println("What do you want to do? \n 1.edit \n 2.add \n 3.delete \n 4.list");
                    choice_2 =Project.in.nextInt();
                    switch(choice_2){
                        case 1: admin.edit_patient();
                             break; 
                        case 2:  admin.add_patient();
                             break; 
                        case 3: admin.delete_patient();
                             break; 
                        case 4: admin.list_patient();
                             break; 
                        default:System.out.println("Invalide choice");
                    }
                break;
                
            case 3:
                System.out.println("What do you want to do? \n 1.edit \n 2.add \n 3.delete \n 4.list");
                    choice_2 =Project.in.nextInt();
                    switch(choice_2){
                        case 1: admin.edit_depatrtment();
                            break; 
                        case 2: admin.add_depatrtment(); 
                            break; 
                        case 3: admin.delete_department();
                            break; 
                        case 4: admin.list_depatrtment();
                            break; 
                        default:System.out.println("Invalide choice");
                    }
                break;
            case 4:
                admin.view_report();
                break;
            case 5:
                admin.view_report();
                break;
            case 6:
                choice =6;
                break;
                
             default:
               System.out.println("Invalide choice");
        }
        }
    }  
    public void Patientmain(){
        System.out.println("What is your name? ");
        String name=Project.in.next();
        System.out.println("What is your ID? ");
        int id=Project.in.nextInt();
        Patient patient = new Patient(id,name);
        ArrayList <Patient> patientt =new ArrayList<Patient>();
        patientt.add(patient);
        Project.patient.put(id, patientt);
        int choice=0;
        while(choice!=4){
        System.out.println("What do you want? \n 1.Request appointment \n 2.View report \n 3.view bills \n 4.Exit");
        choice =Project.in.nextInt();
        switch(choice){
            case 1:
                patient.requestappointment();
                break;
                
            case 2:
               patient.Accessing_Medical_Record();
                break;
                
            case 3:
               patient.Accessing_Billing ();
                break;
            case 4:
                choice =4;
                break;
            default:
               System.out.println("Invalide choice");
        }
        // Patient schedules appointments
        }
    }
    public void Doctormain(){
        int choice=0;
        while(choice!=4){
        System.out.println("What do you want? \n 1.Managing_Appointments \n 2.Prescribe_medications \n 3.view reports \n 4.Exit");
        choice =Project.in.nextInt();
        Doctor doctor=new Doctor();
        switch(choice){
            case 1:
              doctor.Managing_Appointments();
                break;
                
            case 2:
               doctor.Prescribe_medications();
                break;
                
            case 3:
              doctor.view_reports();
                break;
            case 4:
                choice =4;
                break;
            default:
               System.out.println("Invalide choice");
        }
    }
}
}

public class Project 
{
    public static Map<Integer, ArrayList<Doctor>> Doctors = new HashMap<>();
    public static ArrayList<String> department = new ArrayList<>();
    public static Map<Integer ,ArrayList<Patient>> patient = new HashMap<>();
    public static Scanner in=new Scanner(System.in);
    public static int doc_c=0;
    public static void main(String[] args) 
    {
        Inzialzeation();
        int choice=0;
        man x=new man();
        while(choice!=4)
        {
        System.out.println("Who are you? \n 1.Admin \n 2.Doctor \n 3.Patient \n 4.Exit");
        choice= in.nextInt();
        if (choice < 1 || choice > 4) {
                System.out.println("Invalid choice. Please try again.");
                continue;
            }
        
        switch(choice){
            case 1:
                
                x.Adminmain();
                break;
                
            case 2:
                x.Doctormain();
                break;
                
            case 3:
                x.Patientmain();
                break;
            case 4:
                choice= 4;
        }
        

        }
        in.close();
    }
    private static void Inzialzeation(){
        try{
            
            File counter=new File("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\doctors.txt");
            if(counter.exists()){
            Scanner input=new Scanner(counter);
            
            if(input.hasNext())
            Project.doc_c=input.nextInt();
            while(input.hasNext()){
                Doctor a=new Doctor();
                a.doctor_id=input.nextInt();
                a.doctor_name=input.next();
                a.specialization=input.next();
            int departmentKey = switch(a.specialization){
                case "Cardiology"->1 ;
                case "Dental"->2 ;
                case "Dermatology"->3 ;
                case"Emergency"->4 ;
                default -> throw new IllegalArgumentException("Unknown specialization: " + a.specialization);
                };
                Project.Doctors.putIfAbsent(departmentKey, new ArrayList<>());
                Project.Doctors.get(departmentKey).add(a);
                }
            input.close();
            }
            
            counter=new File("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\patients.txt");
            if (counter.exists()){
            Scanner input = new Scanner(counter);
            while(input.hasNext()){
                Patient b=new Patient(input.nextInt(),input.next());
                Project.patient.putIfAbsent((b.patient_id), new ArrayList<>());
                Project.patient.get(b.patient_id).add(b);
            }
            input.close();
            }
            counter=new File("C:\\Users\\pc\\Documents\\NetBeansProjects\\Project\\src\\main\\java\\com\\mycompany\\project\\departments.txt");
            Scanner input = new Scanner(counter);
            while(input.hasNext()){
                String c=input.next();
                Project.department.add(c);
            }
            input.close();
            }
        catch(Exception e){
            System.out.println(e);
        }
    }
}